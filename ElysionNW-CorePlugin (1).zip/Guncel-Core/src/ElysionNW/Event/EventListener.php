<?php 
/*

  ______               _   
 |  ____|             | |  
 | |____   _____ _ __ | |_ 
 |  __\ \ / / _ \ '_ \| __|
 | |___\ V /  __/ | | | |_ 
 |______\_/ \___|_| |_|\__|
                           
                           
*/

namespace ElysionNW\Event;

use ElysionNw\Base;
use ElysionNW\Event\EventListener;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Server;
use pocketmine\Player;

class EventListener implements Listener{
	
	public function __construct(Base $plugin){
		$this->pl = $plugin;
	}
	public function onJoin(PlayerJoinEvent $event){
           $katilan = $o->getName();
           $event->setJoinMessage("§bkatilan §6Sunucuya Girdi!");
}
}
