<?php

namespace ElysionNW\Core;

use ElysionNW\Base;
use ElysionNW\Core\Discord;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};

class Discord extends Command{

	
	public function __construct(Base $plugin){
        parent::__construct("discord", "Discord Sunucumuz", "/discord");
        $this->plugin = $plugin;
    }
    
	public function execute(CommandSender $o, string $label, array $args) {
		$this->kForm($o);
	}
     public function kform(Player $o){
		$f = new ModalForm(function(Player $o, $args){
			if($args === null){
				return true;
			}
			switch ($args){
				case 0:
				break;
			}
		});
		$f->setTitle("Discord Bilgi");
		$f->setContent("§bDiscord Menüsünde Bilgi Edinebilirsin \n\nDiscord Grubumuzda Eğlence, Şikayet Ve Güzel Dostluklar Elde Edip Kurucularada Ulaşabilirsin Ne Duruyorsun? \n\n §bDiscord Sunucumuzun Linki: §chttps://discord.gg/nHBQujZ");
		$f->setButton1("§cÇıkış");
		$f->setButton2("");
		$f->sendToPlayer($o);
	}
}