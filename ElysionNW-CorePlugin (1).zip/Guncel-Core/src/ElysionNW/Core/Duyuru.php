<?php

namespace ElysionNW\Core;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use ElysionNW\Base;
use ElysionNW\Core\Duyuru;
use onebone\economyapi\EconomyAPI;

class Duyuru extends Command{

    public function __construct(Base $plugin){
        parent::__construct("duyuru", "duyuru", "/duyuru");
        $this->plugin = $plugin;
        $this->setPermission("core.duyuru");
    }

    public $prefix = "§7[§l§6DUYURU§r§7]";
    
    public function execute(CommandSender $cs, string $label, array $args){
        if (!$this->testPermission($cs)){
            return false;
        }
        if (count($args) == 0){
            $cs->sendMessage("§cKullanım: §7/duyuru (mesaj)");
        }else{
            $this->getServer()->broadcastMessage($this->prefix."§e ".implode(" ", $args));
        }


    }

}