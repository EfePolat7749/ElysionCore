<?php

namespace ElysionNW\Core;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use ElysionNW\Base;
use ElysionNW\Core\Tamir;
use onebone\economyapi\EconomyAPI;

class Tamir extends Command{
    public function __construct(Base $plugin){
        parent::__construct("tamir", "Paralı Eşya tamir etme", "/tamir");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $cs, string $label, array $args){
        $oyuncu = $cs->getPlayer();

        if ($oyuncu->haspermission("vip.tamir") || $oyuncu->haspermission("tamir.vip+")){
            $esya = $oyuncu->getInventory()->getItemInHand();

            if ($esya->getId() == 0){
                $oyuncu->sendPopup("Elinde hiçbir şey tutmuyorsun");
            }else{
                $esya->setDamage(0);
                $oyuncu->getInventory()->setItemInHand($esya);
                $oyuncu->sendPopup("Eşya tamir edildi");
            }
        }else{
            $esya = $oyuncu->getInventory()->getItemInHand();
            $hasar = $oyuncu->getInventory()->getItemInHand()->getDamage();
            $fiyat = "2";
            $tutar = $hasar * $fiyat;
            $param = EconomyAPI::getInstance()->myMoney($oyuncu);

            if ($param >= $tutar){
                $esya->setDamage(0);
                $oyuncu->getInventory()->setItemInHand($esya);
                $oyuncu->sendPopup("Eşya tamir edildi\nTutar: " . $tutar);
            }else{
                $oyuncu->sendMessage("Bu eşyayı tamir edebilmek için en az " . $tutar . " TL'niz olması gerek");
            }
        }
    }

}