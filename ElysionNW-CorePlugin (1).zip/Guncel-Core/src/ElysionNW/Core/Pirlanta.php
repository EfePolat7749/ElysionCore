<?php

namespace ElysionNW\Core;

use ElysionNW\Core\Pirlanta;
use ElysionNW\Base;
use pocketmine\plugin\PluginBase;
use pocketmine\command\{Command, CommandSender, ConsoleCommandSender};
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\ItemFactory;
use pocketmine\item\Item;
use jojoe77777\FormAPI\{SimpleForm, CustomForm, ModalForm};

class Pirlanta extends Command{
	
	public function __construct(Base $plugin){
		$this->pl = $plugin;
		parent::__construct("pirlanta","Pırlanta Komutları","/pirlanta");
		}
		
		 public function execute(CommandSender $o, string $lbl, array $args){
     $this->anaForm($o);
	
	}

	public function anaForm(Player $o){
		$f = new SimpleForm(function (Player $o, $args){
			if($args !== null){
				return true;
			}
			switch ($args){
				case 0:
				$this->pirlantaGor($o);
				break;
				case 1:
				$this->pirlantaBilgi($o);
				break;
				case 2:
				$this->pirlabtaMarket($o);
				break;
				case 3:
				$this->pirlantaC($o);
				break;
			}
		});
		$nick = $o->getName();
		$f->setTitle("$nick Pırlanta Form");
		$f->addButton("§ePırlantana Bak!");
		$f->addButton("§ePırlanta Bilgi!");
		$f->addButton("§ePırlanta Market!");
		$f->addButton("§ePırlanta Çevir!");
		$f->sendToPlayer($o);
	}
	public function pirlantaGor(Player $o){
		$f = new SimpleForm(function (Player $o, $args){
			if($args !== null){
				return true;
			}
			switch($args){
				case 0:
				$count = 0;
        foreach($o->getInventory()->getContents() as $item)
        {
            if($item->getId() == $this->id[48])
            {
                $count = $count + $item->getCount();
            }
        }
        $o->sendMessage("
        §6*§5Elyison§fNW §bPırlanta Bak!§6*
        §dPırlanta Miktarın: §e$count
        §eIyi Oyunlar!");
				break;
				case 1:
				$this->anaForm($o);
				break;
			}
		});
		
	  $f->setTitle("Pırlantana Bak");
		$f->setContent("");
		$f->addButton("Tıkla Ve Gör!");
		$f->addButton("Ana Menüye Git!");
		$f->sendToPlayer($o);
	}
	public function pirlantaBilgi(Player $o){
		$f = new SimpleForm(function (Player $o, $args){
			if($args === null){
				return true;
			}
			switch($args){
				case 0:
			  $this->anaForm($o);
				break;
			}
		});
		
		$nickname = $o->getName();
	  $f->setTitle("Pırlanta Bilgi");
		$f->setContent("§anickname Merhaba Burda Pırlanta Yla Ilgili Tüm Bilgilere Sahip Olabilirsin!\n§aPırlanta Nedir Ve Ne Işe Yarar?
	  §6Pırlanta Oyun Içi Para Birimidir. Pırlanta Market Ile Eşya Alinabilir Ve Pırlanta Cevir ile Taşlsrı pırlantaya çevirebilirsin.\n §aPırlanta Nerden Bulurum?	 \n §6Pırlantayı Taş Kazarak Çıkarabilirsin (Oran Düşüktür!) Pırlanta Hammaddeden Yosun Taşı Kırıp Cevir Menüsünden Çevirerek, Lapis Kazarak (Oran Taşa Göre daha yüksektir!) Çıkartabilirsin!
	  
	  §aPırlanta Alım Satımı Yasakmıdır?
\n\nHayır Arkadaşina Ister Pırlantanı Ver Ister Sat!
	\n\n
§aEn Kolay Yolu Nedir?\n\n§6En Hızlı Ve Kolay Pırlanta Kasmanın Yolu Pırlanta Hammaddeye Gidip Yosun Taşlarını Çevir Menüsünden Pırlantaya Çevirmektir!	");
		$f->addButton("Ana Menüye Git!");
		$f->sendToPlayer($o);
	}
	public function pirlantaC(Player $o){
		$form = new CustomForm(function (Player $o, $args){
			if($args === null){
             return true;
            }
            $sayi = $args[1];
            if (is_numeric($sayi)) {
                if ($sayi >= 1) {
                    if ($o->getInventory()->contains(Item::get(48, 0, $sayi))){
                        $o->getInventory()->removeItem(Item::get(48, 0, $sayi));
                        $o->getInventory()->addItem(Item::get(377,0, $sayi));
                        $o->sendMessage("§aBaşarıyla $sayi kadar pırlanta çevirdin!");

                    }else{
                        $o->sendMessage("§cEnvanterinde yeteri kadar Yosun Taşı yok!");
                    }
                }else{
                    $o->sendMessage("§c0 Adet Çeviremssin");
                }
            }else{
                $o->sendMessage("§§cLütfen harf girme!");
            }
        });
        $form->setTitle("$isim Pırlanta Çevir");
        $form->addLabel("\n §aPırlanta Çeviri\n\n§aEnvanterindeki Pirlanta Sayina Bakmak Icin /pirlanta dan Pirlanta Bak Menüsüne Giderek Bakabilirsin!\n\n\n");
        $form->addInput("§6Miktar:", "Örn; 32");
        $form->sendToPlayer($o);
    }
	  	public function pirlantaMarket(Player $o){
		$f = new SimpleForm(function (Player $o, $args){
			if($args === null){
				return true;
			}
			switch($args){
				case 0:
				$nick = $o->getName();
			  if($o->getInventory()->contains(Item::get(377,1,4))){
			  	$o->getInventory()->removeItem(Item::get(377,1,4));
			  	$esya = Item::get(276,0,1);
			  	$balta = Item::get(279,0,1);
			  	$kazma = Item::get(278,0,1);
					$buyu1 = Enchantment::getEnchantment(9); //keskinlik
					$buyu3 = new EnchantmentInstance($buyu3, 15);
					$buyu3 = Enchantment::getEnchantment(15); //verimlilik
					$buyu1 = new EnchantmentInstance($buyu3, 20);
					$buyu2 = Enchantment::getEnchantment(17); //kırılmazlık
					$buyu2 = new EnchantmentInstance($buyu2, 15);
					$esya->addEnchantment($buyu1);
					$esya->addEnchantment($buyu2);
					$esya->setCustomName("§6Pırlanta §cKılıç\n§7§oSatın Alan $nick");	
					$o->getInventory()->addItem($esya);
					$o->sendMessage("§8[§a✓§8] §7Envanterinize §c1 §6Pırlanta Kılıç §7eklendi!");
					$kazma->addEnchantment($buyu1);
					$kazma->addEnchantment($buyu3);
				$kazma->setCustomName("§bPırlanta §cKazma\n§7§oSatın Alan: $nick");	
				$o->getInventory()->addItem($kazma);
				$balta->addEnchantment($buyu3);
				$balta->addEnchantment($buyu1);
				$balta->setCustomName("§bPırlanta §cBalta\n§7§oSatın Alan: $nick");	
				$o->getInventory()->addItem($balta);
					}else{
					$o->sendMessage("§8[§l§cX§r§8]§7Bu eşyayı almak için yeterli pırlantan yok!");
					}
				break;
				case 1:
				$nick = $o->getName();
				if($o->getInventory()->contains(Item::get(48,0,500))){
					$o->getInventory()->removeItem(Item::get(48,0,500));
					$pirlanta = Item::get(377,1,1);
					$pirlanta->setCustomName("§6500 PIRLANTA\n§7§oEmektar: $nick");
					$o->getInventory()->addItem($pirlanta);
					$o->sendMessage("§cEnvanterine 500 Pirlanta Eklendi!");
				}
				break;
				case 2:
				 if($o->getInventory()->contains(Item::get(48,1,250))){
			  	$o->getInventory()->removeItem(Item::get(48,1,250));
			  	$kilic = Item::get(276,0,1);
			  	$balta = Item::get(279,0,1);
			  	$kazma = Item::get(278,0,1);
					$buyu1 = Enchantment::getEnchantment(9); //keskinlik
					$buyu3 = new EnchantmentInstance($buyu3, 15);
					$buyu3 = Enchantment::getEnchantment(15); //verimlilik
					$buyu1 = new EnchantmentInstance($buyu3, 20);
					$buyu2 = Enchantment::getEnchantment(17); //kırılmazlık
					$buyu2 = new EnchantmentInstance($buyu2, 15);
					
					}else{
					$o->sendMessage("§8[§l§cX§r§8]§7Bu eşyayı almak için yeterli pırlantan yok!");
					}
					case 3:
					 if($o->getInventory()->contains(Item::get(377,1,1))){
			  	$o->getInventory()->removeItem(Item::get(377,1,1));
			  	$kilic = Item::get(276,0,1);
			  	$balta = Item::get(279,0,1);
			  	$kazma = Item::get(278,0,1);
					$buyu1 = Enchantment::getEnchantment(9); //keskinlik
					$buyu3 = new EnchantmentInstance($buyu3, 15);
					$buyu3 = Enchantment::getEnchantment(15); //verimlilik
					$buyu1 = new EnchantmentInstance($buyu3, 20);
					$buyu2 = Enchantment::getEnchantment(17); //kırılmazlık
					$buyu2 = new EnchantmentInstance($buyu2, 15);
          $kazma->addEnchantment($buyu1);
					$kazma->addEnchantment($buyu3);
				$kazma->setCustomName("§bPırlanta §cKazma\n§7§oSatın Alan: $nick");	
				$o->getInventory()->addItem($kazma);
					}else{
					$o->sendMessage("§8[§l§cX§r§8]§7Bu eşyayı almak için yeterli pırlantan yok!");
					}
					break;
					case 4:
					if($o->getInventory()->contains(Item::get(377,1,1))){
			  	$o->getInventory()->removeItem(Item::get(377,1,1));
			  	$kilic = Item::get(276,0,1);
			  	$balta = Item::get(279,0,1);
			  	$kazma = Item::get(278,0,1);
					$buyu1 = Enchantment::getEnchantment(9); //keskinlik
					$buyu3 = new EnchantmentInstance($buyu3, 15);
					$buyu3 = Enchantment::getEnchantment(15); //verimlilik
					$buyu1 = new EnchantmentInstance($buyu3, 20);
					$buyu2 = Enchantment::getEnchantment(17); //kırılmazlık
					$buyu2 = new EnchantmentInstance($buyu2, 15);
          $balta->addEnchantment($buyu1);
					$balta->addEnchantment($buyu3);
				$kazma->setCustomName("§bPırlanta §cBalta\n§7§oSatın Alan: $nick");	
				$o->getInventory()->addItem($balta);
					}else{
					$o->sendMessage("§8[§l§cX§r§8]§7Bu eşyayı almak için yeterli pırlantan yok!");
					}
					break;
				case 5:
				$this->anaForm($o);
				break;
			}
		});
		
	  $f->setTitle("Pırlanta Market");
		$f->setContent("Kitleri Almak Için 500 Pırlanta Dönüştürmelisin !");
		$f->addButton("§bPırlanta El Kit\n2000 Pırlanta",1,"https://cdn2.iconfinder.com/data/icons/file-and-document-set-1-1/48/Shop-512.png");
		$f->addButton("§b500 Pırlanta\n500 Yosun Taşı!",1,"https://cdn2.iconfinder.com/data/icons/file-and-document-set-1-1/48/Shop-512.png");
		$f->addButton("§bPırlanta Kılıç\n250 Pırlanta",1,"https://cdn2.iconfinder.com/data/icons/file-and-document-set-1-1/48/Shop-512.png");
		$f->addButton("§bPırlanta Kazma\n500 Pırlanta",1,"https://cdn2.iconfinder.com/data/icons/file-and-document-set-1-1/48/Shop-512.png");
		$f->addButton("§bPırlanta Balta\n500 Pırlanta",1,"https://cdn2.iconfinder.com/data/icons/file-and-document-set-1-1/48/Shop-512.png");
		$f->addButton("§cAna Menü",1,"https://cdn2.iconfinder.com/data/icons/file-and-document-set-1-1/48/Shop-512.png");	
		$f->sendToPlayer($o);
	}
}
