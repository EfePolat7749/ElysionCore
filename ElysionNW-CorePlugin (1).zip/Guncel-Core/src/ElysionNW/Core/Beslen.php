<?php

namespace ElysionNW\Core;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use ElysionNW\Base;
use ElysionNW\Core\Beslen;

class Beslen extends Command{

    public function __construct(Base $plugin){
        parent::__construct("beslen", "Beslenme", "/beslen");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $cs, string $label, array $args){
        $oyuncu = $cs->getPlayer();

        if ($oyuncu->haspermission("vip.beslen") || $oyuncu->haspermission("vip.+")){
            $oyuncu->sendPopup("Açlığın giderildi");
            $oyuncu->setFood(20);
        }else{
            $oyuncu->sendPopup("Bu komutu kullanmak için vip olmalısın!");
        }
    }

}