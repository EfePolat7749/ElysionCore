<?php

namespace ElysionNW\Core;

use ElysionNW\Base;
use ElysionNW\Core\AdminPanel;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};

class AdminPanel extends Command{
	
	public function __construct(Base $plugin){
        parent::__construct("apanel", "Admin Console", "/apanel");
        $this->plugin = $plugin;
    }
    
	public function execute(CommandSender $o, string $label, array $args) {
		$this->apanelForm($o);
	}
	 public function apanelForm(Player $o){
        $form = new SimpleForm(function (Player $o, $data){
            $result = $data[0];
            if($result === null){
                return true;
            }
            switch($result){
                case 0:
                    $this->omForm($o);
                    break;
                case 1:
                    $this->kickForm($o);
                    break;
                case 2:
                    $this->timeForm($o);
                    break;
                case 3:
                    $this->banForm($o);
                    break;
                case 4:
                    $this->sayForm($o);
                    break;
                case 5:
                    $this->stForm($o);
                    break;
                case 6:
                    $this->flyForm($o);
                    break;
                case 7:
                    break;
            }
        });
        $form->setTitle("§3Admin Paneli");
        $form->setContent("§eAşağıdaki Butonlardan Istediğin Işlemi Yapabilirsin!");
        $form->addButton("§cOyun Modunu Değiştir\n§7Tıkla", 0,"textures/items/paper");
        $form->addButton("§cOyuncu At\n§7Tıkla", 0,"textures/items/paper");
        $form->addButton("§cZamanı Ayarla\n§7Tıkla", 0,"textures/items/paper");
        $form->addButton("§cOyuncu Banla\n§7Tıkla", 0,"textures/items/paper");
        $form->addButton("§cDuyuru Yap\n§7Tıkla", 0,"textures/items/paper");
        $form->addButton("§cSohbeti Temizle\n§7Tıkla", 0,"textures/items/paper");
        $form->addButton("§cUç\n§7Tıkla", 0,"textures/items/paper");
        $form->addButton("§4Menüden Ayrıl", 0,"textures/blocks/barrier");
        $form->sendToPlayer($o);
     }
     public function omForm(Player $o){
            $form = new SimpleForm(function (Player $o, $data){
                $result = $data[0];
                if($result === null){
                    return true;
                }
                switch($result){
                    case 0:
                        $o->setGamemode(1);
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $o->sendPopup("§aOyun Modun Güncellendi!(Author ElysionNW)");
                        break;
                    case 1:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $o->setGamemode(0);
                        $o->sendPopup("§aOyun Modun Güncellendi(Author ElysionNW)");
                        break;
                    case 2:
                        $this->panelForm($o);
                        break;
                }
            });
            $form->setTitle("§3Oyun Modu Seçici");
            $form->setContent("§eAşağıdan Oyun Modunu Seçebilirsin");
            $form->addButton("§cYaratıcı Mod\n§7Tıkla");
            $form->addButton("§cHayatta Kalma Modu\n§7Tıkla");
            $form->addButton("§cGeri");
            $form->sendToPlayer($o);
        }

        public function kickForm(Player $o){
              $form = new CustomForm(function (Player $o, $data){
                $result = $data[0];
                if($result === null){
                    return true;
                }
                switch($result){
                    case 0:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $this->playerName = $data[1];
                        $this->getServer()->getCommandMap()->dispatch($o, "kick " . $this->playerName);
                        break;
                }
            });
            $form->setTitle("§3Oyuncu Atma Menüsü");
            $form->addInput("§eAşağıya Atmak Istediğin Oyuncunun Adını Ve Sebebini Yaz !\n\n","§7Oyuncu Adı");
            $form->addLabel("");
            $form->sendToPlayer($o);
        }

        public function timeForm(Player $o){
        $form = new SimpleForm(function (Player $o, $data){
                $result = $data[0];
                if($result === null){
                    return true;
                }
                switch($result){
                    case 0:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $this->getServer()->dispatchCommand($o, "time set day");
                        $o->sendPopup("§aSaat Ayarlandı");
                        break;
                    case 1:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $this->getServer()->dispatchCommand($o, "time set night");
                        $o->sendPopup("§aSaat Ayarlandı");
                        break;
                    case 2:
                        $this->panelForm($o);
                        break;
                }
            });
            $form->setTitle("§3Saat Ayarlama Menüsü");
            $form->setContent("§eAşağıdaki Butonlardan Saati Ayarlayabilirsin");
            $form->addButton("§cSabah Yap\n§7Tıkla");
            $form->addButton("§cGece Yap\n§7Tıkla");
            $form->addButton("§cGeri");
            $form->sendToPlayer($o);
        }

        public function banForm(Player $o){            
            $form = new CustomForm(function (Player $o, $data){
                $result = $data[0];
                if($result === null){
                    return true;
                }
                switch($result){
                    case 0:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $this->playerName = $data[1];
                        $this->getServer()->getCommandMap()->dispatch($o, "ban " . $this->playerName);
                        break;
                }
            });
            $form->setTitle("§3Oyuncu Banlama Menüsü");
            $form->addInput("§eAşağıya Banlamak Istediğin Oyuncunun Adını Ve Sebebini Yaz !\n\n","§7Oyuncu Adı");
            $form->addLabel("");
            $form->sendToPlayer($o);
        }

        public function sayForm(Player $o){
            $form = new CustomForm(function (Player $o, $data){
                $result = $data[0];
                if($result === null){
                    return true;
                }
                switch($result){
                    case 0:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $this->playerName = $data[1];
                        $this->getServer()->broadcastMessage("§l§bElysion§fNW: ".implode(" ", $data));
                        break;
                    case 1:
                        $this->panelForm($o);
                        break;
                }
            });
            $form->setTitle("§3Duyuru Menüsü(SohbetEtmekYasak)");
            $form->addInput("§eDuyuru Yapmak Için Bir Yazı Yaz\n\n","§7Yazı");
            $form->addLabel("");
            $form->sendToPlayer($o);
        }

        public function stForm(Player $o){
           $form = new SimpleForm(function (Player $o, $data){
                $result = $data[0];
                if($result === null){
                    return true;
                }
                switch($result){
                    case 0:
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $this->getServer()->BroadcastMessage(" ");
                        $o->sendPopup("§aSohbet Temizlendi");
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        break;
                    case 1:
                        $this->panelForm($o);
                        break;
                }
            });
            $form->setTitle("§3Sohbet Temizleme Menüsü");
            $form->setContent("§eAşağıdaki Butona Basarak Sohbeti Temizleyebilirsin");
            $form->addButton("§cSohbeti Temizle\n§7Tıkla");
            $form->addButton("§cGeri");
            $form->sendToPlayer($o);
        }

        public function flyForm(Player $o){
            $form = new SimpleForm(function (Player $o, $data){
                $result = $data[0];
                if($result === null){
                    return true;
                }
                switch($result){
                    case 0:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $o->setAllowFlight(true);
                        $o->addTitle("§eUç\n§aAktif");
                        break;
                    case 1:
                        $o->getLevel()->addSound(new BlazeShootSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $o->setAllowFlight(false);
                        $o->addTitle("§eUç\n§cDe-Aktif");
                        break;
                }
            });
            $form->setTitle("§3Uçma Menüsü");
            $form->setContent("§eAşağıdaki Butona Basarak Uçma Işlemini Gerçekleştirebilirsin");
            $form->addButton("§cUçmayı Aktif Et\n§7Tıkla");
            $form->addButton("§cUçmayı De-Aktif Et\n§7Tıkla");
            $form->addButton("§cGeri");
            $form->sendToPlayer($o);
        }
    }
