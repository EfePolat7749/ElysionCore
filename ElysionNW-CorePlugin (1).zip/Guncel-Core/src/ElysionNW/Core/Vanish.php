<?php



namespace ElysionNW\Core;



use ElysionNW\Base;

use ElysionNW\Core\Vanish;

use pocketmine\command\Command;

use pocketmine\command\CommandSender;

use pocketmine\Player;

use pocketmine\plugin\Plugin;

use onebone\economyapi\EconomyAPI;


class Vanish extends Command{



	

	public function __construct(Base $plugin){
        parent::__construct("gizlen", "Yetkililer Için Gizlen!", "/gizlen");
        $this->plugin = $plugin;

    }

    

	public function execute(CommandSender $o, string $label, array $args) {
     if ($o->hasPermission("gizlen.komut")) {
            if (isset($args[0])) {
                if (strtolower($args[0] == "ac")) {
                    $o->setGamemode(3);
                    $o->sendMessage("§bGizlendin Kapatmak Için /gizlen kapat");
                }
                if (strtolower($args[0] == "kapat")) {
                    $g->setGamemode(0);
                    $g->sendMessage("§6Gizlenme Kapatıldı!");
                }
            }else{
                $g->sendMessage("§cKullanım: §e/gizlen ac -kapat");
            }
        }else{
            $g->sendMessage("§cBu komutu kullanma yetkin yok!");
        }
      }
}