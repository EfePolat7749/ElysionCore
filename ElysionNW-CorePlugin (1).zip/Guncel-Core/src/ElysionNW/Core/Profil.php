<?php

namespace ElysionNW\Core;

use ElysionNW\Base;
use ElysionNW\Core\Profil;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};
use onebone\economyapi\EconomyAPI;

class Profil extends Command{

	public function __construct(Base $plugin){
        parent::__construct("profil", "Profil", "/profil");
        $this->plugin = $plugin;
    }
    public function execute(CommandSender $o, string $label, array $args) {
      $this->menuForm($o);
	}

	public function menuForm(Player $o){
		$f = new CustomForm(function(Player $o, $data){
			if($data === null){
				return true;
			}
		});
		$adi = $o->getName();
		$parasi = EconomyAPI::getInstance()->myMoney($o);
		$aclik = $o->getFood() * 5;
		$can = $o->getHealth() * 5;
		$ping = $o->getPing();
		$ulke = $o->getLocale();
		$f->setTitle("$adi Oyuncunun Profili");
		$f->addLabel("§eIsmin:§a $adi\n\n§eParan:§a $parasi\n\n§eAçlık:§a $aclik\n\n§eCan:§a $can\n\n§ePing:§a $ping\n\n§eUlke:§a $ulke");
		$f->sendToPlayer($o);
	}
 }