<?php

namespace ElysionNW\Core;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};
use ElysionNW\Base;
use ElysionNW\Core\Id;

class Id extends Command{

    public function __construct(Base $plugin){
        parent::__construct("id", "Item ID Menü", "/id");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $cs, string $label, array $args){
       $formapi = new SimpleForm(function(Player $oyuncu, $data){
        $oyuncu = $cs->getPlayer();
            if ($data == null){
                return true;
            }
        });
        $formapi->setTitle("§cItem ID Menü");
        $formapi->addLabel("§cEşya: §f" . $oyuncu->getInventory()->getItemInHand()->getName());
        $formapi->addLabel("§cID: §f" . $oyuncu->getInventory()->getItemInHand()->getId() . ":" . $oyuncu->getInventory()->getItemInHand()->getDamage());
        $formapi->addLabel("§cAdet: §f" . $oyuncu->getInventory()->getItemInHand()->getCount());

        $formapi->sendToPlayer($oyuncu);
    }

}