<?php



namespace ElysionNW\Core;



use ElysionNW\Base;

use ElysionNW\Core\Yer;

use pocketmine\command\Command;

use pocketmine\command\CommandSender;

use pocketmine\Player;

use pocketmine\plugin\Plugin;

use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};

use onebone\economyapi\EconomyAPI;


class Yer extends Command{



	

	public function __construct(Base $plugin){

        parent::__construct("yer", "Yer", "/yer");

        $this->plugin = $plugin;

    }

    

	public function execute(CommandSender $o, string $label, array $args) {

		$this->yerForm($o);
	}

	public function yerForm(Player $o){
		$f = new SimpleForm(function (Player $o, $data){
		if($data === null){
			return true;
		}
		switch($data){
			case 0:
			$this->getServer()->loadLevel("lobi");
      $dunya = $this->getServer()->getLevelByName("lobi");
      $base = $dunya->getSafeSpawn();
      $o->teleport($base, 0, 0);
      $o->teleport(new Vector3($base->getX(), $base->getY(), $base->getZ()));
      $o->sendMessage("§8» §eLobiye ışınlandınız");
			break;
			case 1:
			$this->getServer()->loadLevel("arena");
      $dunya = $this->getServer()->getLevelByName("arena");
      $base = $dunya->getSafeSpawn();
      $o->teleport($base, 0, 0);
      $o->teleport(new Vector3($base->getX(), $base->getY(), $base->getZ()));
      $o->sendMessage("§8» §eArenaya ışınlandınız");
			break;
			case 2:
			if(EconomyAPI::getInstance()->myMoney($o) >= 5000){
			EconomyAPI::getInstance()->reduceMoney($o, 5000);
			$this->getServer()->loadLevel("nether");
      $dunya = $this->getServer()->getLevelByName("nether");
      $base = $dunya->getSafeSpawn();
      $o->teleport($base, 0, 0);
      $o->teleport(new Vector3($base->getX(), $base->getY(), $base->getZ()));
      $o->sendMessage("§8» Nethere ışınlandınız");
      }else{
      	$o->sendMessage("§cYetersiz Para Miktarı!");
      }
			break;
			case 3:
			if(EconomyAPI::getInstance()->myMoney($o) >= 10000){
			EconomyAPI::getInstance()->reduceMoney($o, 10000);
			$this->getServer()->loadLevel("end");
      $dunya = $this->getServer()->getLevelByName("end");
      $base = $dunya->getSafeSpawn();
      $o->teleport($base, 0, 0);
      $o->teleport(new Vector3($base->getX(), $base->getY(), $base->getZ()));
      $o->sendMessage("§8» Ende ışınlandınız");
      }else{
      	$o->sendMessage("§cYetersiz Para Miktarı!");
      }
			break;
		}
	});
	$f->setTitle("Yer Menu");
	$f->addButton("Lobi",1,"https://www.minecraft.net/etc.clientlibs/minecraft/clientlibs/main/resources/img/servers/servers-hub-1.png");
	$f->addButton("Arena",1,"https://www.iconfinder.com/icons/6102722/3d_box_model_printing_icon");
	$f->addButton("Nether",1,"https://my.mcpedl.com/storage/addons/1510/images/963f723bdec6c26933433792c9828964.png");
	$f->addButton("End",1,"https://minecraft.gamepedia.com/File:End_Stone_JE3_BE2.png");
	$f->sendToPlayer($o);
	}
	}