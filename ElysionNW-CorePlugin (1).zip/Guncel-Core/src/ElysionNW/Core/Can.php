<?php

namespace ElysionNW\Core;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use ElysionNW\Base;
use ElysionNW\Core\Can;

class Can extends Command{
    public function __construct(Base $plugin){
        parent::__construct("can", "Can Doldurma", "/can");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $cs, string $label, array $args){
        $oyuncu = $cs->getPlayer();

        if ($oyuncu->haspermission("vip.beslen") || $oyuncu->haspermission("beslen.vip+")){
            $oyuncu->sendPopup("Canın dolduruldu");
            $oyuncu->setHealth(20);
        }else{
            $oyuncu->sendPopup("Bu komutu kullanmak için vip olmalısın!");
        }
        return true;
    }

}