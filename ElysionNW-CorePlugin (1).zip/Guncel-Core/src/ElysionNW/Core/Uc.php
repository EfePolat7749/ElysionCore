<?php

namespace ElysionNW\Core;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use ElysionNW\Base;
use ElysionNW\Core\Uc;

class Uc extends Command{
    public function __construct(Base $plugin){
        parent::__construct("uc", "Uçma Komutu", "/uc");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $cs, string $label, array $args){
        $oyuncu = $cs->getPlayer();

        if ($oyuncu->haspermission("fly.vip") || $oyuncu->haspermission("fly.vip+")){
            if ($oyuncu->getAllowFlight() == true) {
                $oyuncu->setAllowFlight(false);
                $oyuncu->sendPopup("Uçma kapatıldı");
            }else{
                $oyuncu->setAllowFlight(true);
                $oyuncu->sendPopup("Uçma açıldı");
            }
        }else{
            $oyuncu->sendPopup("Bu komutu kullanmak için vip olmalısın!");
        }
    }

}