<?php

namespace ElysionNW\Core;

use ElysionNW\Base;
use ElysionNW\Core\Kurallar;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};

class Kurallar extends Command{

	public function __construct(Base $plugin){
        parent::__construct("kurallar", "kurallar", "/kurallar");
        $this->plugin = $plugin;
    }
   
 	public function execute(CommandSender $o, string $label, array $args) {
		$this->kurallarForm($o);
	}


public function kurallarForm(Player $o){
		$f = new SimpleForm(function(Player $o, $data){
			if($data === null){
				return true;
			}
			switch($data){
				case 0;
				$o->sendMessage("§8» §dUmarım Kurallara Uyarsın.");
				break;
			}
		});
		
		$f->setTitle("§bElysion§rNW §cKurallar Menüsü");
		$f->setContent("
§fHile Açmak Yasak!
§f[§c1 Günlük Ban§f] 
§fKüfür Etmek Yasak!
§f[§c10 Dk Susturma§f] 
§fHakaret Etmek Yasak!
§f[§c5 Dk Susturma§f] 
§fCinsellik Yasak!
§f[§cKick-Ban§f]
§fArgo Kelime Kullanımı Yasak!
§f[§c1 Dk Susturma§f]
§fSunucu İsmi Vermek Yasak!
§f[§c1 Günlük Ban§f]
§fSiyaset Yapmak Yasak!
§f[§c5 Dk Susturma§f]
§fYetkiliyle Alaycı Vb. Konuşmak Yasak!
§f[§c1 Günlük Ban§f]
§fSunucuyu Kötülemek Yasak!!
§d[§cIP-Ban§f]


§cÖnemli: §eYeni Ban Sistemi İle Ban Süreli Olacaktır.");
		$f->addButton("§aAnladım");
		$f->sendToPlayer($o);
}
}