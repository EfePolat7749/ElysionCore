<?php

namespace ElysionNW\Core;

use ElysionNW\Base;
use ElysionNW\Core\Kadro;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};

class Kadro extends Command{

	
	public function __construct(Base $plugin){
        parent::__construct("kadro", "Kadromuz", "/kadro");
        $this->plugin = $plugin;
    }
    
	public function execute(CommandSender $o, string $label, array $args) {
		$this->kadroForm($o);
	}
	 public function kadroForm(Player $o){
		$f = new CustomForm(function(Player $o, $data){
			if($data === null){
				return true;
			}
		});
		
		$f->setTitle("§bElysion§fNW");
		$f->addLabel("§7Aşagıdaki Kişiler §bElysion§bNW kadrosunda yer alan Yetkililerdiir.\n\n\n§4§lNOT:§r§c Hile, Küfür Gibi durumlarda §3FaceBook §bElysion§fNW §Şikayet Ve Öneri Grubuna Bildirirsen Gereken Yapılır.");
		$f->addButton("§cKurucu \n§0TKaganPaSa", 0,"textures/items/diamond_sword");
		$f->addButton("§aYönetici \n§zSIauGhTeR", 0,"textures/items/emerald");
          $f->addButton("§bGeliştirici\n§0EfePolat7749", 0,"textures/items/diamond");
		$f->addButton("§bGeliştirici\n§0ItsMeArda", 0,"textures/items/diamond");
		$f->addButton("§eGörevli\n§0YiğitKral25", 0,"textures/items/gold_ingot");
		$f->addButton("§eGörevli\n§cYok!", 0,"textures/items/gold_ingot");
                $f->addButton("\n", 0,"textures/items/iron_ingot");
                $f->addButton("\n", 0,"textures/items/iron_ingot");
                $f->addButton("\n", 0,"textures/items/iron_ingot");
		$f->addButton("§cX §7Ayrıl");
		$f->sendToPlayer($o);
	}
	
}