<?php

namespace ElysionNW\Core;

use ElysionNW\Base;
use ElysionNW\Core\Panel;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};

class Panel extends Command{

	
	public function __construct(Base $plugin){
        parent::__construct("panel", "Panel", "/panel");
        $this->plugin = $plugin;
    }
    
	public function execute(CommandSender $o, string $label, array $args) {
		$this->panelForm($o);
	}
       public function panelForm(Player $o){
		$form = new CustomForm(function(Player $o, $data){
			if($data === null){
				return true;
            }
            switch($data){
                case 0:
                    if($o->hasPermission("feed.kmt")){
                        $o->getLevel()->addSound(new AnvilUseSound($o));
                        $o->getLevel()->addParticle(new HappyVillagerParticle($o));
                        $o->setFood(20);
                        $o->sendPopup("§aAçlığın Giderildi");
                        break;
                    }
                case 1:
                    if($o->hasPermission("heal.kmt")){
                        $o->getLevel()->addSound(new AnvilUseSound($o));
                        $o->getLevel()->addParticle(new HeartParticle($o));
                        $o->setHealth(20);
                        $o->sendPopup("§aCanın Dolduruldu");
                        break;
                    }
                case 2:
                    if($o->hasPermission("flyac.kmt")){
                        $o->getLevel()->addSound(new AnvilUseSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $o->setAllowFlight(true);
                        $o->addTitle("§eUçuş Modu\n§aEtkin");
                        break;
                    }
                case 3:
                    if($o->hasPermission("flykapa.kmt")){
                        $o->getLevel()->addSound(new AnvilUseSound($o));
                        $o->getLevel()->addParticle(new HappyVillagerParticle($o));
                        $o->setAllowFlight(false);
                        $o->addTitle("§eUçuş Modu\n§cDevre Dışı");
                        break;
                    }
                case 4:
                    if($o->hasPermission("envt.kmt")){
                        $o->getLevel()->addSound(new AnvilUseSound($o));
                        $o->getLevel()->addParticle(new FlameParticle($o));
                        $o->getInventory()->clearAll();
                        $o->sendPopup("§aEnvanterin Temizlendi");
                        break;
                    }
                case 5:
                    if($o->hasPermission("repair.kmt")){
                        $o->getLevel()->addSound(new AnvilUseSound($o));
                        $o->getLevel()->addParticle(new BubbleParticle($o));
                        $esya = $o->getInventory()->getItemInHand();
                            $esya->setDamage(0);
                            $o->getInventory()->setItemInHand($esya);
                            $o->sendPopup("§aEşya Onarıldı");
                            break;
                        }
                        case 6:
                            break;
                    }
        });
        $form->setTitle("§3Panel Sistemi");
        $form->setContent("§eAşağıdaki Butonlara Basarak Işlem Yapabilirsin!");
        $form->addButton("§cAçlığını Doldur\n§7Tıkla", 0,"textures/materials/steak");
        $form->addButton("§cCanını Doldur\n§7Tıkla", 0,"textures/materials/apple");
        $form->addButton("§cUçuş Modunu Aç\n§7Tıkla", 0,"textures/block/emerald_block");
        $form->addButton("§cUçuş Modunu Kapat\n§7Tıkla", 0,"textures/block/redstone_block");
        $form->addButton("§cEnvanterini Temizle\n§7Tıkla", 0,"textures/materials/wheat");
        $form->addButton("§cElindeki Eşyayı Onar\n§7Tıkla", 0,"textures/tool_recipes/diamond_pickaxe");
        $form->addButton("§4Ayrıl");
        $form->sendToPlayer($o);
    }
}