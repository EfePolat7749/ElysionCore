<?php
/*
Efe Polat Tarafinfan ElysionNW ye özel Olarak Kodlanmıştır!
Saygılar ...
@ElysionNW Core v0.1
@author: EfePolat7749
*/
namespace ElysionNW;

use ElysionNW\Core\Yer;
use ElysionNW\Core\Kurallar;
use ElysionNW\Core\Discord;
use ElysionNW\Core\Kadro;
use ElysionNW\Core\Panel;
use ElysionNW\Core\Profil;
use ElysionNW\Core\Duyuru;
use ElysionNW\Core\Can;
use ElysionNW\Core\Beslen;
use ElysionNW\Core\Id;
use ElysionNW\Core\Tamir;
use ElysionNW\Core\Tpa;
use ElysionNW\Core\Tpar;
use ElysionNW\Core\Uc;
use ElysionNW\Core\AdminPanel;
use ElysionNW\Core\Pirlanta;
use ElysionNW\Core\Tpak;
use ElysionNW\Core\Haykir;
use ElysionNW\Core\Vanish;
use ElysionNW\Event\EventListener;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pockektmine\Player;

class Base extends PluginBase implements Listener{

public function onEnable(){
 $this->getServer()->getPluginManager()->registerEvents($this, $this);
 $this->getServer()->getCommandMap()->register("kadro", new Kadro($this));
 $this->getServer()->getCommandMap()->register("profil", new Profil($this));
 $this->getServer()->getCommandMap()->register("kurallar", new Kurallar($this));
 $this->getServer()->getCommandMap()->register("panel", new Panel($this));
 $this->getServer()->getCommandMap()->register("dc", new Discord($this));
 $this->getServer()->getCommandMap()->register("yer", new Yer($this));
 $this->getServer()->getCommandMap()->register("uc", new Uc($this));
$this->getServer()->getCommandMap()->register("duyuru", new Duyuru($this));
$this->getServer()->getCommandMap()->register("tamir", new Tamir($this));
$this->getServer()->getCommandMap()->register("beslen", new Beslen($this));
$this->getServer()->getCommandMap()->register("can", new Can($this));
$this->getServer()->getCommandMap()->register("haykir", new Haykir($this));
$this->getServer()->getCommandMap()->register("id", new Id($this));
$this->getServer()->getCommandMap()->register("apanel", new AdminPanel($this));
$this->getServer()->getCommandMap()->register("pirlanta", new Pirlanta($this));
$this->getServer()->getCommandMap()->register("gizlen", new Vanish($this));
//$this->getServer()->getCommandMap()->register("oran", new OranUI($this));
//$this->getServer()->getCommandMap()->register("sat", new Sat($this));

//EVENTS
$this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
//$this->getServer()->getPluginManager()->registerEvents(new Oran($this), $this);
}
public function davetGonder(Player $oyuncu, Player $hedef): void{
        if (isset($args[0])){
            $this->davet[$hedef->getName()] = $oyuncu->getName();
        }
    }
    public function davetKontrol(string $isim): bool{
        return isset($this->davet[$isim]);
    }
    public function davet(string $isim){
        return $this->davet[$isim];
    }

    public function tpak(string $isim): void{
        $hedef = $this->getServer()->getPlayer($isim);
        if($this->davetKontrol($isim)){
            $oyuncu = $this->getServer()->getPlayer($this->davet($isim));
            $oyuncu->teleport($hedef->asPosition());
            unset($this->davet[$isim]);
            $oyuncu->sendPopup("§8[§c!§8] §c".$isim->getName() . " §7Işınlanma isteğinizi kabul etti. Işınlanıyorsun...");
        }else{
            $hedef->sendMessage("§8[§c!§8] §cSize gelen bir ışınlanma isteği yok.");
        }
    }

    public function tpar(string $isim) : void{
        $hedef = $this->getServer()->getPlayer($isim);
        if($this->davetKontrol($isim)){
            $oyuncu = $this->getServer()->getPlayer($this->davet($isim));
            unset($this->davet[$isim]);
            $oyuncu->sendMessage("§8[§c!§8] §c".$isim->getName() . "§7cşınlanma isteğinizi reddetti");

        }else{
            $hedef->sendMessage("§8[§c!§8] §4Size gelen bir ışınlanma isteği yok.");
        }
    }
}
